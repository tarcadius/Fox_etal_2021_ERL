#------------------------------------------------------------------------------
# Program:     The LDAR Simulator (LDAR-Sim) 
# File:        LDAR-Sim main
# Purpose:     Interface for parameterizing and running LDAR-Sim.
#
# Copyright (C) 2019  Thomas Fox, Mozhou Gao, Thomas Barchyn, Chris Hugenholtz
#    
# This file is for peer review. Do not distribute or modify it in any way.
# This program is presented WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
#------------------------------------------------------------------------------

from weather_lookup import *
from ldar_sim import *
from time_counter import *
from batch_reporting import *
from generic_functions import get_prop_rate
import numpy as np
import pandas as pd
import os
import datetime
import time
import gc

#------------------------------------------------------------------------------
######################   BEFORE RUNNING PLEASE CHECK:
#   OUTPUT FOLDER NAME
#   SITES LIST
#   SURVEY FREQUENCY
#   EMPIRICAL DISTRIBUTION (D1 = Clearstone; D2 = Ravikumar)
#   LEAK COUNT DISTRIBUTION (D1 = Clearstone; D2 = Ravikumar)
#   VENTING VS. NO VENTING
#   QUANTIFICATION ACCURACY SCENARIO (Q1 = Perfect; Q2 = easy; Q3 = hard)
#   MINIMUM SURVEY INTERVAL (SCREENING)

#-----------------------------Global parameters--------------------------------
freqs = ['01', '02', '03', '04', '05', '06', '07', '08', '09']

for i in range(len(freqs)):

    survey_frequency = freqs[i]
    master_output_folder = '' + survey_frequency + '/'
    sites = 'sites_F' + survey_frequency + '.csv'
    
    #********************************Remember to update survey interval*****************************************************************
    
    ref_program = 'Screen'               # Name must match reference program below for batch plots
    n_simulations = 10                  # Minimum of 2 simulations to get batch plots
    n_timesteps = 2190                  # Up to ~5600 for 16 year nc file
    spin_up = 365
    start_year = 2011
    operator_strength = 1
    an_data = 'an_2003_2018_AB.nc'
    fc_data = 'fc_2003_2018_AB.nc'
    leaks = 'rates_Clearstone.csv'
    counts = 'counts_Clearstone.csv'
    vents = 'ZA_site_emissions_2018.csv'
    t_offsite = 'time_offsite_ground.csv'
    subtype_times = [False, 'subtype_times.csv']     # If True, will overwrite site-specific times using subtype times
    wd = ''
    site_samples = [True, 500]
    write_data = True # Must be TRUE to make plots and maps
    make_plots = True
    make_maps = False
    
    static_thresholds = np.array([0.01, 0.02, 0.04, 0.08, 0.16, 0.24, 0.32, 0.40, 0.48, 0.64, 0.80, 0.92])
    #-----------------------------Define programs----------------------------------
    # Load emission rate data for experiment
    rates = np.array(pd.read_csv(leaks).iloc [:, 0])  * 3600 # Convert g/s to g/h
    ST_df = get_prop_rate(static_thresholds, rates) 
    
    programs = [        # Minimum 2 programs to get batch plots
            {
                'methods': {
                        'OGI_FU': {
                                 'name': 'OGI_FU',
                                 'n_crews': 1,
                                 'min_temp': -50,
                                 'max_wind': 50,
                                 'max_precip': 50,
                                 'max_workday': 10,
                                 'cost_per_day': 1500,
                                 'reporting_delay': 0,
                                 'MDL': [0.47, 0.01]
                                 },
                        'screen': {
                                 'name': 'screen',
                                 'n_crews': 1,
                                 'min_temp': -50,
                                 'max_wind': 50,
                                 'max_precip': 50,
                                 'min_interval': (365/int(survey_frequency)) - 5,
                                 'max_workday': 10,
                                 'cost_per_day': 1500,
                                 'follow_up_thresh': 0,
                                 'follow_up_ratio': 1,
                                 'reporting_delay': 0,
                                 'QA': 0, #Standard deviation of the percent error
                                 'MDL': 0 # grams/hour  
                                 },
                            },        
                'master_output_folder': master_output_folder,
                'output_folder': master_output_folder + 'Screen',
                'timesteps': n_timesteps,
                'start_year': start_year,
                'an_data': an_data,
                'fc_data': fc_data,
                'infrastructure_file': sites,
                'leak_file': leaks,
                'count_file': counts,
                'vent_file': vents,
                't_offsite_file': t_offsite,
                'working_directory': wd,
                'site_samples': site_samples,
                'subtype_times': subtype_times,
                'simulation': None,
                'consider_daylight': False,
                'consider_operator': True,
                'consider_venting': False,
                'repair_delay': 0,
                'LPR': 0.0065,           
                'max_det_op': 0.00,
                'spin_up': spin_up,
                'write_data': write_data,
                'make_plots': make_plots,
                'make_maps': make_maps,
                'start_time': time.time(),
                'operator_strength': operator_strength,
                'sensitivity': {'perform': False, 
                                'program': 'operator', 
                                'batch': [True, 1]}
            }
            ]
    
    output_directory = programs[0]['working_directory'] + '/' + master_output_folder
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    
    for ST in range(len(static_thresholds)):
        gc.collect()
        programs[0]['methods']['screen']['follow_up_thresh'] = ST_df.iloc[ST,2]
        programs[0]['output_folder'] = master_output_folder + 'Screen' + str(ST_df.iloc[ST,0])
        
        for i in range(n_simulations):     
            for j in range(len(programs)):
                parameters = programs[j]
                    
                gc.collect()
                print('Program ' + str(j + 1) + ' of ' + str(len(programs)) + '; simulation ' + str(i + 1) + ' of ' + str(n_simulations))
                
                parameters['simulation'] = str(i)
            
        #------------------------------------------------------------------------------
        #-----------------------Initialize dynamic model state-------------------------
            
                state = {
                    't': None,   
                    'operator': None,       # operator gets assigned during initialization
                    'methods': [],          # list of methods in action
                    'sites': [],            # sites in the simulation
                    'flags': [],            # list of sites flagged for follow-up
                    'leaks': [],            # list of all current leaks
                    'tags': [],             # leaks that have been tagged for repair
                    'weather': None,        # weather gets assigned during initialization
                    'daylight': None,       # daylight hours calculated during initialization
                    'init_leaks': [],       # the initial leaks generated at timestep 1
                    'empirical_vents': [0], # vent distribution created during initialization
                    'max_rate': None        # the largest leak in the input file
                }
                
        #------------------------Initialize timeseries data----------------------------
                
                timeseries = {
                    'datetime': [],
                    'active_leaks': [],
                    'new_leaks': [],
                    'n_tags': [],
                    'cum_repaired_leaks': [],
                    'daily_emissions_kg': []
                }
                
        #-----------------------------Run simulations----------------------------------
                
                if __name__ == '__main__':
                
                    # Initialize objects
                    
                    state['weather'] = weather_lookup (state, parameters)
                    state['t'] = time_counter (parameters)
                    sim = ldar_sim (state, parameters, timeseries)
                            
                   
                # Loop through timeseries
                while state['t'].current_date <= state['t'].end_date:
                    sim.update ()
                    state['t'].next_day ()
                
                # Clean up and write files
                sim.finalize ()
    
    # Do batch reporting
    if write_data == True:
        # Create a data object...
        reporting_data = batch_reporting(output_directory, programs[0]['start_year'], spin_up, ref_program)
        if n_simulations > 1:
            reporting_data.program_report()
            if len(programs) > 1:        
               reporting_data.batch_report()
               reporting_data.batch_plots()
    
    
    # Write metadata
    metadata = open(output_directory + '/metadata.txt','w')
    metadata.write(str(programs) + '\n' +
    str(datetime.datetime.now()))
    
    metadata.close()
        
    ST_df.to_csv(output_directory + '/ST_df.csv', index = False)
    
    os.chdir(wd)
    
