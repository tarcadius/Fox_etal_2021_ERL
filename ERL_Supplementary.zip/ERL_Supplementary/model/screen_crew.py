#------------------------------------------------------------------------------
# Program:     The LDAR Simulator (LDAR-Sim) 
# File:        screen crew
# Purpose:     Initialize each screen crew under screen company
#
# Copyright (C) 2019  Thomas Fox, Mozhou Gao, Thomas Barchyn, Chris Hugenholtz
#    
# This file is for peer review. Do not distribute or modify it in any way.
# This program is presented WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
#------------------------------------------------------------------------------

import numpy as np
from datetime import timedelta
import math
import numpy as np

class screen_crew:
    def __init__ (self, state, parameters, config, timeseries, deployment_days, id):
        '''
        Constructs an individual screen crew based on defined configuration.
        '''
        self.state = state
        self.parameters = parameters
        self.config = config
        self.timeseries = timeseries
        self.deployment_days = deployment_days
        self.crewstate = {'id': id}     # Crewstate is unique to this agent
        self.crewstate['lat'] = 0.0
        self.crewstate['lon'] = 0.0
        self.worked_today = False
        return

    def work_a_day (self):
        '''
        Go to work and find the leaks for a given day
        '''
        self.worked_today = False
        self.candidate_flags = []
        work_hours = None
        max_work = self.parameters['methods']['screen']['max_workday']
        
        if self.parameters['consider_daylight'] == True:
            daylight_hours = self.state['daylight'].get_daylight(self.state['t'].current_timestep)
            if daylight_hours <= max_work:
                work_hours = daylight_hours
            elif daylight_hours > max_work:
                work_hours = max_work
        elif self.parameters['consider_daylight'] == False:
            work_hours = max_work
        
        if work_hours < 24 and work_hours != 0:
            start_hour = (24 - work_hours) / 2
            end_hour = start_hour + work_hours
        else:
            print('Unreasonable number of work hours specified for screen crew ' + str(self.crewstate['id']))
               
        self.state['t'].current_date = self.state['t'].current_date.replace(hour = int(start_hour))              # Set start of work day
        while self.state['t'].current_date.hour < int(end_hour):
            facility_ID, found_site, site = self.choose_site ()
            if not found_site:
                break                                   # Break out if no site can be found
            self.visit_site (facility_ID, site)
            self.worked_today = True
        
        # Flag sites according to the flag ratio
        if len(self.candidate_flags) > 0:
            self.flag_sites(self.candidate_flags)

        if self.worked_today == True:
            self.timeseries['screen_cost'][self.state['t'].current_timestep] += self.parameters['methods']['screen']['cost_per_day']

        return


    def choose_site (self):
        '''
        Choose a site to survey.

        '''
            
        # Sort all sites based on a neglect ranking
        self.state['sites'] = sorted(self.state['sites'], key=lambda k: k['screen_t_since_last_LDAR'], reverse = True)

        facility_ID = None                                  # The facility ID gets assigned if a site is found
        found_site = False                                  # The found site flag is updated if a site is found

        # Then, starting with the most neglected site, check if conditions are suitable for LDAR
        for site in self.state['sites']:

            # If the site hasn't been attempted yet today
            if site['attempted_today_screen?'] == False:
            
                # If the site is 'unripened' (i.e. hasn't met the minimum interval set out in the LDAR regulations/policy), break out - no LDAR today
                if site['screen_t_since_last_LDAR'] < self.parameters['methods']['screen']['min_interval']:
                    self.state['t'].current_date = self.state['t'].current_date.replace(hour = 23)
                    break
    
                # Else if site-specific required visits have not been met for the year
                elif site['surveys_done_this_year_screen'] < int(site['screen_required_surveys']):
    
                    # Check the weather for that site
                    if self.deployment_days[site['lon_index'], site['lat_index'], self.state['t'].current_timestep] == True:
                    
                        # The site passes all the tests! Choose it!
                        facility_ID = site['facility_ID']   
                        found_site = True
    
                        # Update site
                        site['screen_surveys_conducted'] += 1
                        site['surveys_done_this_year_screen'] += 1
                        site['screen_t_since_last_LDAR'] = 0
                        break
                                            
                    else:
                        site['attempted_today_screen?'] = True

        return (facility_ID, found_site, site)

    def visit_site (self, facility_ID, site):
        '''
        Look for emissions at the chosen site.
        '''

        # Sum all the emissions at the site
        leaks_present = []
        site_cum_rate = 0
        for leak in self.state['leaks']:
            if leak['facility_ID'] == facility_ID:
                if leak['status'] == 'active':
                    leaks_present.append(leak)
                    site_cum_rate += leak['rate']  
                    
        # Add vented emissions
        venting = 0
        if self.parameters['consider_venting'] == True:
            venting = self.state['empirical_vents'][np.random.randint(0, len(self.state['empirical_vents']))]
            site_cum_rate += venting
                    
        # Simple binary detection module 
        detect = False
        if site_cum_rate > (self.config['MDL']*0.024):  # g/hour to kg/day
            detect = True    
        
        if detect == True:
            # If source is above follow-up threshold, calculate measured rate using quantification error
            quant_error = np.random.normal(0, self.config['QA'])
            measured_rate = None
            if quant_error >= 0:
                measured_rate = site_cum_rate + site_cum_rate*quant_error                
            if quant_error < 0:
                denom = abs(quant_error - 1)
                measured_rate = site_cum_rate/denom         
                        
            if measured_rate > self.config['follow_up_thresh']:
                
                # Put all necessary information in a dictionary to be assessed at end of day
                site_dict = {
                        'site': site,
                        'leaks_present': leaks_present,
                        'site_cum_rate': site_cum_rate,
                        'measured_rate': measured_rate,
                        'venting': venting
                        }
                
                self.candidate_flags.append(site_dict)
                
        elif detect == False:
            site['screen_missed_leaks'] += len(leaks_present)
                
        self.state['t'].current_date += timedelta(minutes = int(site['screen_time']))
        self.state['t'].current_date += timedelta(minutes = int(self.state['offsite_times'][np.random.randint(0, len(self.state['offsite_times']))]))
        self.timeseries['screen_sites_visited'][self.state['t'].current_timestep] += 1

    def flag_sites (self, candidate_flags):
        '''
        Flag the most important sites for follow-up.

        '''
        # First, figure out how many sites you're going to choose
        n_sites_to_flag = len(candidate_flags) * self.config['follow_up_ratio']
        n_sites_to_flag = int(math.ceil(n_sites_to_flag))
        
        measured_rates = []
        sites_to_flag = []
        
        for i in candidate_flags:
            measured_rates.append(i['measured_rate'])
            
        measured_rates.sort(reverse = True)
        target_rates = measured_rates[:n_sites_to_flag]
        
        for i in candidate_flags:
            if i['measured_rate'] in target_rates:
                sites_to_flag.append(i)
        
        for i in sites_to_flag:  
            site = i['site']
            leaks_present = i['leaks_present']
            site_cum_rate = i['site_cum_rate']
            venting = i['venting']
            
            # If the site is already flagged, your flag is redundant
            if site['currently_flagged'] == True:
                self.timeseries['screen_flags_redund1'][self.state['t'].current_timestep] += 1
            
            elif site['currently_flagged'] == False:
                # Flag the site for follow up
                site['currently_flagged'] = True
                site['date_flagged'] = self.state['t'].current_date
                site['flagged_by'] = self.config['name']
                self.timeseries['screen_eff_flags'][self.state['t'].current_timestep] += 1
                
                # Does the chosen site already have tagged leaks?
                redund2 = False
                for leak in leaks_present:
                    if leak['date_found'] != None:
                        redund2 = True
                        
                if redund2 == True:
                    self.timeseries['screen_flags_redund2'][self.state['t'].current_timestep] += 1
                
                # Would the site have been chosen without venting?
                if self.parameters['consider_venting'] == True:
                    if (site_cum_rate - venting) < self.config['follow_up_thresh']:
                        self.timeseries['screen_flags_redund3'][self.state['t'].current_timestep] += 1        

        return 