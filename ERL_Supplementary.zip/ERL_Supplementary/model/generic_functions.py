#------------------------------------------------------------------------------
# Program:     The LDAR Simulator (LDAR-Sim) 
# File:        Generic functions
# Purpose:     Generic functions for running LDAR-Sim.
#
# Copyright (C) 2019  Thomas Fox, Mozhou Gao, Thomas Barchyn, Chris Hugenholtz
#    
# This file is for peer review. Do not distribute or modify it in any way.
# This program is presented WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
#------------------------------------------------------------------------------

import numpy as np
import pandas as pd

def gap_calculator (condition_vector):
    """
    This function calculates max gaps between daily activites in a time series.
    Requires only a single binary vector describing whether a condition was met.
    """
    
    # Find the index of all days in which the condition is true
    max_gap = None
    indices = np.where(condition_vector == True)
    
    # If there are no condition days, max_gap equals the vector length
    if len(indices[0]) == 0:
        max_gap = len(condition_vector)

    # If there is only one condition day, get max_gap
    elif len(indices[0]) == 1:
        start_gap = indices[0][0]   
        end_gap = len(condition_vector) - indices[0][0]
        max_gap = max(start_gap, end_gap)
        
    # If there are multiple condition days, calculate longest gap   
    elif len(indices[0] > 1):  
        start_gap = indices[0][0]   
        mid_gap = max(abs(x - y) for (x, y) in zip(indices[0][1:], indices[0][:-1]))
        end_gap = len(condition_vector) - indices[0][-1]
        max_gap = max(start_gap, mid_gap, end_gap)
        
    return (max_gap)


def get_prop_rate (proportion, rates):

    """
     The puropose of this function is to calculate the emission rate(s) that 
     correspond(s) with a desired proportion total emissions for a given emission 
     size distribution. It estimates the MDL needed to find the top X percent 
     of sources for a given leak size distribution.
     
     Inputs are: (1) a proportion value that represents top emitting sources, 
     and (2) a distribution of emission rates (either leaks or sites).
     
     For example, given a proportion of 0.01 and a leak-size distribution,
     this function will return an estimate of the detection limit that will
     ensure that all leaks in the top 1% of leak sizes are found. 
      
    """

    # Sort emission rates, get cumulative rates, and convert to proportions
    rates_sorted = sorted(rates)
    cum_rates = np.cumsum(rates_sorted)
    cum_rates_prop = cum_rates/max(cum_rates)
    
    # Get relative position of each element in emissions distribution
    p = 1. * np.arange(len(rates)) / (len(rates) - 1 )
   
    # Estimate proportion of emissions that correspond with a given proportion of top emitters.
    # 100% of sites account for 100% of emissions. 0% of sites account for 0% of emissions.
    f = lambda x: np.interp(x, xp = p, fp = cum_rates_prop)
    prop_rate = f(1 - proportion)
    prop_above = 1 - prop_rate
    
    # Convert result (prop emissions) back to cumulative rate
    cum_rate = prop_rate * max(cum_rates)
    
    # Estimate emission rate that corresponds with cumulative rate
    f2 = lambda x: np.interp(x, cum_rates, rates_sorted)
    rate = f2(cum_rate) 
    
    df = pd.DataFrame({'Proportion': proportion, 'Prop Emissions': prop_above, 'follow_up_thresh': rate})   
    
    return (df)