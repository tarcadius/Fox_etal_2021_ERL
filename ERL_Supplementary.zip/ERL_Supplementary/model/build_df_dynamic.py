
import os
import pandas as pd
import numpy as np

output_directory = ''
name = 'LPRN_O0_DT_D1_V0_Q1'

method = 'DT'
distribution = 'Clearstone'
venting = False
q_accuracy = 0

spin_up = 365
n_sites = 500
n_sims = 10

FU_ratios = np.array([0.01, 0.02, 0.04, 0.08, 0.16, 0.24, 0.32, 0.40, 0.48, 0.64, 0.80, 0.92])

# Go to directory with program folders
os.chdir(output_directory)
directories = next(os.walk('.'))[1]

file_lists = [[] for i in range(len(directories))]

master_dict = {
        'sim_number': [],
        'ratio': [],
        'method': [],
        'venting': [],
        'distribution': [],
        'q_accuracy': [],
        
        'surveys': [],
        
        'FU_prop': [],
        'operator_tag_prop': [],
        
        'total_emissions_mean': [],
        'total_emissions_std': [],
        'site_emissions_mean': [],
        'site_emissions_std': [],

        'active_leaks_mean': [],
        'active_leaks_std': [],
        'site_active_leaks_mean': [],
        'site_active_leaks_std': []
        }

# List files
for i in range(len(directories)):
    path = output_directory + directories[i]
            
    # List subdirectories
    os.chdir(path)
    subdirs = next(os.walk('.'))[1]
    
    
    for j in range(len(subdirs)):
        path2 = path + '/' + subdirs[j]
                  
        for k in os.listdir(path2):
            if os.path.isfile(os.path.join(path2,k)) and 'timeseries' in k:
                
                file_lists[i].append(path2 + '/' + k)

os.chdir(output_directory)
            
# Delete any empty lists (to enable additional folders, e.g. for sensitivity analysis)
file_lists = [item for item in file_lists if len(item) > 0]


for i in range(len(file_lists)):
    
    sim_numbers = np.tile(np.linspace(1, n_sims, n_sims), len(subdirs))
    ratios = np.repeat(np.array(FU_ratios), n_sims)
    
    for j in range(len(file_lists[i])):
        
        # Open csv
        df = pd.read_csv(file_lists[i][j])
        
        # slice off spin-up
        df = df.iloc[spin_up-1:,]

        master_dict['sim_number'].append(sim_numbers[j])
        master_dict['ratio'].append(ratios[j])
        
        master_dict['method'].append(method)
        master_dict['distribution'].append(distribution)
        master_dict['venting'].append(venting)
        master_dict['q_accuracy'].append(q_accuracy)

        master_dict['surveys'].append(int(file_lists[i][j].split("_F", 1)[1][0:2]))
        
        master_dict['FU_prop'].append(np.sum(df["OGI_FU_sites_visited"])/np.sum(df["screen_sites_visited"]))
        master_dict['operator_tag_prop'].append(np.sum(df["operator_tags"])/(np.max(df["cum_repaired_leaks"]) - np.min(df["cum_repaired_leaks"])))
            
        master_dict['total_emissions_mean'].append(np.mean(df["daily_emissions_kg"]))
        master_dict['total_emissions_std'].append(np.std(df["daily_emissions_kg"]))
        master_dict['site_emissions_mean'].append(np.mean(df["daily_emissions_kg"]/n_sites))
        master_dict['site_emissions_std'].append(np.std(df["daily_emissions_kg"]/n_sites))
        
        master_dict['active_leaks_mean'].append(np.mean(df["active_leaks"]))
        master_dict['active_leaks_std'].append(np.std(df["active_leaks"]))
        master_dict['site_active_leaks_mean'].append(np.mean(df["active_leaks"]/n_sites))
        master_dict['site_active_leaks_std'].append(np.std(df["active_leaks"]/n_sites))
        
df_out = pd.DataFrame(master_dict)
df_out.to_csv(name + '.csv', index = False)

