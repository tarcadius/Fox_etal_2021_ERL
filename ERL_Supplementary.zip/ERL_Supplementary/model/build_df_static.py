
import os
import pandas as pd
import numpy as np

output_directory = ''
name = 'ST_D1_V1_Q3'


method = 'ST'
distribution = 'Clearstone'
venting = True
q_accuracy = 3

spin_up = 365
n_sites = 500
n_sims = 10

# Go to directory with program folders
os.chdir(output_directory)
directories = next(os.walk('.'))[1]

file_lists = [[] for i in range(len(directories))]
MDL_dfs = [[] for i in range(len(directories))]
master_dict = {
        'sim_number': [],
        'proportion': [],
        'emission_prop': [],
        'MDL': [],
		
		'method': [],
        'venting': [],
        'distribution': [],
        'q_accuracy': [],
        
        'surveys': [],

        'FU_prop': [],
        'operator_tag_prop': [],
        
        'total_emissions_mean': [],
        'total_emissions_std': [],
        'site_emissions_mean': [],
        'site_emissions_std': [],

        'active_leaks_mean': [],
        'active_leaks_std': [],
        'site_active_leaks_mean': [],
        'site_active_leaks_std': []
        }

# List files
for i in range(len(directories)):
    path = output_directory + directories[i]

    # Import MDL data file
    for file in os.listdir(path):
        if os.path.isfile(os.path.join(path,file)) and 'MDL' in file:           
            MDL_dfs[i].append(path + '/' + file)   
            
            
    # List subdirectories
    os.chdir(path)
    subdirs = next(os.walk('.'))[1]
    
    
    for j in range(len(subdirs)):
        path2 = path + '/' + subdirs[j]
                  
        for k in os.listdir(path2):
            if os.path.isfile(os.path.join(path2,k)) and 'timeseries' in k:
                
                file_lists[i].append(path2 + '/' + k)

os.chdir(output_directory)
            
# Delete any empty lists (to enable additional folders, e.g. for sensitivity analysis)
file_lists = [item for item in file_lists if len(item) > 0]


for i in range(len(file_lists)):
    
#    Import MDL file
    MDL_df = pd.read_csv(MDL_dfs[i][0])
    
    sim_numbers = np.tile(np.linspace(1, n_sims, n_sims), len(subdirs))
    proportions = np.repeat(np.array(MDL_df['Proportion']), n_sims)
    emission_props = np.repeat(np.array(MDL_df['Prop Emissions']), n_sims)
    MDLs = np.repeat(np.array(MDL_df['MDL']), n_sims)
    
    for j in range(len(file_lists[i])):
        
        # Open csv
        df = pd.read_csv(file_lists[i][j])
        
        # slice off spin-up
        df = df.iloc[spin_up-1:,]

        master_dict['sim_number'].append(sim_numbers[j])
        master_dict['proportion'].append(proportions[j])
        master_dict['emission_prop'].append(emission_props[j])
        master_dict['MDL'].append(MDLs[j])
        master_dict['method'].append(method)
        master_dict['distribution'].append(distribution)
        master_dict['venting'].append(venting)
        master_dict['q_accuracy'].append(q_accuracy)

        master_dict['surveys'].append(int(file_lists[i][j].split("_F", 1)[1][0:2]))

        master_dict['FU_prop'].append(np.sum(df["OGI_FU_sites_visited"])/np.sum(df["screen_sites_visited"]))
        master_dict['operator_tag_prop'].append(np.sum(df["operator_tags"])/(np.max(df["cum_repaired_leaks"]) - np.min(df["cum_repaired_leaks"])))
                        
        master_dict['total_emissions_mean'].append(np.mean(df["daily_emissions_kg"]))
        master_dict['total_emissions_std'].append(np.std(df["daily_emissions_kg"]))
        master_dict['site_emissions_mean'].append(np.mean(df["daily_emissions_kg"]/n_sites))
        master_dict['site_emissions_std'].append(np.std(df["daily_emissions_kg"]/n_sites))
        
        master_dict['active_leaks_mean'].append(np.mean(df["active_leaks"]))
        master_dict['active_leaks_std'].append(np.std(df["active_leaks"]))
        master_dict['site_active_leaks_mean'].append(np.mean(df["active_leaks"]/n_sites))
        master_dict['site_active_leaks_std'].append(np.std(df["active_leaks"]/n_sites))
        
df_out = pd.DataFrame(master_dict)
df_out.to_csv(name + '.csv', index = False)

#### Calculate OGI baseline using same method as above
#output_directory = 'D:\OneDrive - University of Calgary\Documents\Thomas\PhD\Thesis\LDAR_Sim\manuscript2\simulations\static_model/OGI_all_F3/OGI/'
#spin_up = 365
#n_sites = 500
#n_sims = 10
#
## Go to directory with program folders
#os.chdir(output_directory)
#
#files = next(os.walk('.'))
#file_list = []        
#
#for i in range(len(files[2])):
#    if os.path.isfile(files[2][i]) and 'timeseries' in files[2][i]:        
#       file_list.append(output_directory + '/' + files[2][i])
#        
#OGI_emissions_mean = []
#OGI_emissions_std = []      
#for i in range(len(file_list)):       
#    # Open csv
#    df = pd.read_csv(file_list[i])
#    
#    # slice off spin-up
#    df = df.iloc[spin_up-1:,]
#    
#    OGI_emissions_mean.append(np.mean(df["daily_emissions_kg"]/n_sites))
#    OGI_emissions_std.append(np.std(df["daily_emissions_kg"]/n_sites))
#    
#np.mean(OGI_emissions_mean)
#np.std(OGI_emissions_mean)
#
## For 1 survey, emissions = 7.66 kg/h/site +/- 0.71 (1 std)
## For 3 surveys, emissions = 3.02 kg/h/site +/- 0.27 (1std)
#
########## Figure out baseline emissions (operator only) ################
#output_directory = 'D:\OneDrive - University of Calgary\Documents\Thomas\PhD\Thesis\LDAR_Sim\manuscript2\simulations\static_model/Baseline_F0/Screen0/'
#spin_up = 365
#n_sites = 500
#n_sims = 10
#
## Go to directory with program folders
#os.chdir(output_directory)
#
#files = next(os.walk('.'))
#file_list = []        
#
#for i in range(len(files[2])):
#    if os.path.isfile(files[2][i]) and 'timeseries' in files[2][i]:        
#       file_list.append(output_directory + '/' + files[2][i])
#        
#OGI_emissions_mean = []
#OGI_emissions_std = []      
#for i in range(len(file_list)):       
#    # Open csv
#    df = pd.read_csv(file_list[i])
#    
#    # slice off spin-up
#    df = df.iloc[spin_up-1:,]
#    
#    OGI_emissions_mean.append(np.mean(df["daily_emissions_kg"]/n_sites))
#    OGI_emissions_std.append(np.std(df["daily_emissions_kg"]/n_sites))
#    
#np.mean(OGI_emissions_mean)
#np.std(OGI_emissions_mean)
#
## Baseline emissions (with operator) = 13.65 kg/h/site +/- 1.89 (1 std)